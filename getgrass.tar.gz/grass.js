const fs = require('fs');
const readline = require('readline');
const WebSocket = require('ws');
const { SocksProxyAgent } = require('socks-proxy-agent');
const { v4: uuidv4 } = require('uuid');

const user_id = '097a021b-d2c6-4d01-a437-13847ff48b0e';
const logger = console;

const userAgent =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

const options = {
    headers: {
        'User-Agent': userAgent,
    },
};

const connectWebSocket = (proxyInfo) => {
    const device_id = uuidv4(); // Generate unique device_id for each connection
    logger.info("INFO: Device ID -", device_id);

    const proxy = `socks://${proxyInfo.ip}:${proxyInfo.port}`;
    const agent = new SocksProxyAgent(proxy);

    const ws = new WebSocket('wss://proxy.wynd.network:4650/', { ...options, agent });

    ws.on('open', () => {
        logger.debug(`WebSocket: Connection opened. Using proxy IP: ${proxyInfo.ip}`);
        sendPing(ws, device_id);
    });

    ws.on('message', (data) => {
        const message = JSON.parse(data);
        if (message.action === 'AUTH') {
            const authResponse = {
                id: message.id,
                origin_action: 'AUTH',
                result: {
                    browser_id: device_id,
                    user_id: user_id,
                    user_agent: options.headers['User-Agent'],
                    timestamp: Math.floor(Date.now() / 1000),
                    device_type: 'extension',
                    version: '3.3.2',
                },
            };
            logger.debug('RESPONSE: ', authResponse);
            ws.send(JSON.stringify(authResponse));
        } else if (message.action === 'PONG') {
            const pongResponse = { id: message.id, origin_action: 'PONG' };
            logger.debug('RESPONSE: ', pongResponse);
            ws.send(JSON.stringify(pongResponse));
        } else {
            logger.info('RESPONSE: ', message);
        }
    });

    ws.on('error', (error) => {
        logger.error(`WebSocket: ERROR. Proxy IP: ${proxyInfo.ip}`, error);
        reconnectWebSocket(proxyInfo);
    });

    ws.on('close', () => {
        logger.debug(`WebSocket: Connection closed. Proxy IP: ${proxyInfo.ip}`);
        reconnectWebSocket(proxyInfo);
    });

    logger.debug(`WebSocket: Connecting. Using proxy IP: ${proxyInfo.ip}`);
};

const sendPing = (socket, device_id) => {
    const pingInterval = setInterval(() => {
        const send_message = JSON.stringify({
            id: device_id,
            version: '1.0.0',
            action: 'PING',
            data: {},
        });
        logger.debug('SENDING PING: ', send_message);
        socket.send(send_message);
    }, 20000);

    socket.on('close', () => {
        clearInterval(pingInterval);
    });
};

const reconnectWebSocket = (proxyInfo) => {
    logger.debug(`Attempting to reconnect. Using proxy IP: ${proxyInfo.ip}`);
    setTimeout(() => {
        connectWebSocket(proxyInfo);
    }, 180000); // Retry after 3 mins
};

// Read proxies from file
const readProxiesFromFile = () => {
    const proxies = [];
    const fileStream = fs.createReadStream('proxies.txt');
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity,
    });

    rl.on('line', (line) => {
        const [ip, port] = line.trim().split(':');
        proxies.push({ ip, port });
    });

    rl.on('close', () => {
        // Start WebSocket connections for each proxy
        proxies.forEach((proxyInfo) => {
            connectWebSocket(proxyInfo);
        });
    });
};

readProxiesFromFile();
